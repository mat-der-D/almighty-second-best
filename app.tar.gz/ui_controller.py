import functools
import time

import flet as ft
from ui_model import UIModel, UIState, UIModelHelper
from components import Tower, TowerButton, TowerButtonCircle, ButtonCreator


class UIController:
    def __init__(self, ui_model: UIModel, button_creator: ButtonCreator):
        self.ui_model = ui_model
        self.button_creator = button_creator
        self.__tbc, self.__central_space = self._initialize_ui()

    def ui(self, page_width: int, page_height: int) -> ft.Stack:
        return ft.Stack([
            ft.Row([
                ft.Column([
                    self.__tbc,
                ], expand=True, alignment=ft.MainAxisAlignment.CENTER)
            ], alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Row([
                ft.Column(
                    self.__central_space,
                    spacing=40,
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    expand=True,
                    height=page_height,
                ),
            ])
        ], width=page_width, height=page_height)

    def _initialize_ui(self):
        state = UIModelHelper.create_color_selection()
        tower_buttons = []
        for idx in range(8):
            tower = Tower(*state.stone_towers[idx])
            btn_info = state.buttons[idx]
            btn = self.button_creator.create(
                btn_info.kind,
                functools.partial(self.on_click, idx) if btn_info.is_active else None
            )
            tower_buttons.append(TowerButton(tower, btn))
        tbc = TowerButtonCircle(*tower_buttons)

        central_space = []
        for idx, kind in enumerate(state.center):
            btn = self.button_creator.create(
                kind,
                functools.partial(self.on_click_central, idx)
            )
            central_space.append(btn)

        return tbc, central_space

    def on_click(self, index: int, e):
        for state, wait in self.ui_model.press(index):
            self._process_state(state, wait, e.page)

    def on_click_central(self, index: int, e):
        for state, wait in self.ui_model.press_central(index):
            self._process_state(state, wait, e.page)

    def _process_state(self, state: UIState, wait: float, page: ft.Page):
        self._update_ui(state)
        page.update()
        time.sleep(wait)

    def _update_ui(self, state: UIState):
        for idx in range(8):
            self.__tbc.set_colors(idx, *state.stone_towers[idx])
            btn_info = state.buttons[idx]
            btn = self.button_creator.create(
                btn_info.kind,
                functools.partial(self.on_click, idx) if btn_info.is_active else None
            )
            self.__tbc.set_button(idx, btn)

        self.__central_space.clear()
        for idx, kind in enumerate(state.center):
            btn = self.button_creator.create(
                kind,
                functools.partial(self.on_click_central, idx)
            )
            self.__central_space.append(btn)
