from enum import Enum, auto


class Color(Enum):
    BLACK = auto()
    WHITE = auto()

    def __invert__(self):
        match self:
            case Color.BLACK:
                return Color.WHITE
            case Color.WHITE:
                return Color.BLACK


class ButtonKind(Enum):
    MOVE_FROM = auto()
    MOVE_TO = auto()
    CANCEL_FROM = auto()
    PUT_ON = auto()
    ACCEPT = auto()
    REJECT = auto()
    RETRY = auto()
    PLAYS_FIRST = auto()
    PLAYS_SECOND = auto()
    BLANK = auto()
    LOSE = auto()
    WIN = auto()
