from enum import Enum, auto
from typing import NamedTuple, Callable

import consts
from enums import ButtonKind, Color
from board import Board, Evaluator, ActionKind, Action


class ButtonState(NamedTuple):
    kind: ButtonKind
    is_active: bool


class UIState(NamedTuple):
    stone_towers: list[list[Color]]
    buttons: list[ButtonState]
    center: list[ButtonKind] = []


class State(Enum):
    MOVE_FROM = auto()
    MOVE_TO = auto()
    PUT_ON = auto()
    SECOND_BEST = auto()
    FINISH = auto()


class UIModel:
    def __init__(self, evaluator: Evaluator):
        self.state = State.PUT_ON
        self.board = Board()
        # self.evaluator = Evaluator()  # ToDo: ファイルから読み込む
        self.evaluator = evaluator
        self.from_index: int | None = None
        self.sb_action: Action | None = None

    def press(self, index: int) -> list[tuple[UIState, float]]:
        match self.state:
            case State.MOVE_FROM:
                return self.press_on_move_from(index)
            case State.MOVE_TO:
                return self.press_on_move_to(index)
            case State.PUT_ON:
                return self.press_on_put_on(index)
            case State.SECOND_BEST:
                raise NotImplementedError
            case State.FINISH:
                return self.press_on_retry(index)

        raise NotImplementedError

    def press_on_move_from(self, index: int) -> list[tuple[UIState, float]]:
        legal_actions = list(self.board.legal_actions(Color.BLACK))
        if all(a.kind != ActionKind.MOVE or a.src != index for a in legal_actions):
            return []

        to_set = set(a.dst for a in legal_actions if a.src == index and a != self.sb_action)
        self.from_index = index
        self.state = State.MOVE_TO
        ui_state = UIModelHelper.create_to(self.board, to_set, index)
        return [(ui_state, 0)]

    def press_on_move_to(self, index: int) -> list[tuple[UIState, float]]:
        def ui_state_when_rejected_creator(b: Board, a: Action) -> UIState:
            from_set_ = set(a_.src for a_ in legal_actions if a_ != a)
            return UIModelHelper.create_from(b, from_set_)

        def sb_ui_state_creator(b: Board, a: Action) -> UIState:
            return UIModelHelper.create_move_sb(b, a.src, a.dst)

        legal_actions = list(self.board.legal_actions(Color.BLACK))
        if index == self.from_index:
            self.state = State.MOVE_FROM
            from_set = set(a.src for a in legal_actions if a != self.sb_action)
            ui_state = UIModelHelper.create_from(self.board, from_set)
            self.from_index = None
            return [(ui_state, 0)]

        action = Action.create_move(Color.BLACK, self.from_index, index)
        return self._process_after_action_selected(
            action,
            State.MOVE_FROM,
            ui_state_when_rejected_creator,
            sb_ui_state_creator,
        )

    def press_on_put_on(self, index: int) -> list[tuple[UIState, float]]:
        def ui_state_when_rejected_creator(b: Board, a: Action) -> UIState:
            to_set_ = set(a_.dst for a_ in legal_actions if a_ != a)
            return UIModelHelper.create_put(b, to_set_)

        def sb_ui_state_creator(b: Board, a: Action) -> UIState:
            return UIModelHelper.create_put_sb(b, a.dst)

        legal_actions = list(self.board.legal_actions(Color.BLACK))
        action = Action.create_put(Color.BLACK, index)

        return self._process_after_action_selected(
            action,
            State.PUT_ON,
            ui_state_when_rejected_creator,
            sb_ui_state_creator,
        )

    def _process_after_action_selected(
            self,
            action: Action,
            next_state_when_rejected: State,
            ui_state_when_rejected_creator: Callable[[Board, Action], UIState],
            sb_ui_state_creator: Callable[[Board, Action], UIState],
    ):
        legal_actions = list(self.board.legal_actions(Color.BLACK))

        if self.sb_action == action or action not in legal_actions:
            return []

        state_list = []

        # CPU のセカンドベスト判定
        if self.sb_action is None:
            if self.evaluator.best_actions(self.board, Color.BLACK) == {action}:
                if self.board.winner(Color.WHITE, action) is not None:  # セカンドベストで手が無くなったパターン
                    self.state = State.FINISH
                    state_list.append((UIModelHelper.create_end(self.board), 0))
                    return state_list
                else:
                    self.state = next_state_when_rejected
                    self.clear_memory()
                    self.sb_action = action
                    state_list.append((ui_state_when_rejected_creator(self.board, action), 0))
                    return state_list

        # 確定
        self.board.perform(action)
        self.clear_memory()

        # ゲーム終了条件チェック
        if self.board.winner(Color.BLACK) is not None:
            state_list.append((UIModelHelper.create_end(self.board), 0))
            self.state = State.FINISH
            return state_list

        # ~~ CPU の手番 ~~
        self.append_thinking_direction(state_list)
        cpu_action = self.choose_cpu_action(self.evaluator, self.board, self.sb_action)
        self.sb_action = cpu_action
        self.state = State.SECOND_BEST
        state_list.append((sb_ui_state_creator(self.board, cpu_action), 0))
        return state_list

    def press_on_retry(self, _index: int) -> list[tuple[UIState, float]]:
        self.board = Board()
        self.state = State.PUT_ON
        self.clear_memory()
        return [(UIModelHelper.create_put(self.board, set(range(8))), 0)]

    def press_central(self, index: int) -> list[tuple[UIState, float]]:
        if self.state is not State.SECOND_BEST:
            raise NotImplementedError

        match index:
            case 0:
                return self.press_accept()
            case 1:
                return self.press_reject()
            case _:
                raise NotImplementedError

    def press_accept(self) -> list[tuple[UIState, float]]:
        state_list = []
        self.confirm_cpu_action(state_list, self.sb_action)
        return state_list

    def press_reject(self) -> list[tuple[UIState, float]]:
        state_list = []
        self.append_thinking_direction(state_list)
        cpu_action = self.choose_cpu_action(self.evaluator, self.board, self.sb_action)
        self.confirm_cpu_action(state_list, cpu_action)
        return state_list

    def confirm_cpu_action(self, state_list: list[tuple[UIState, float]], cpu_action: Action):
        # 確定
        self.board.perform(cpu_action)
        state_list.append((
            UIModelHelper.create_determined(self.board, cpu_action),
            consts.CPU_RESULT_DURATION,
        ))
        self.clear_memory()

        # ゲーム終了条件チェック
        if self.board.winner(Color.WHITE) is not None:
            state_list.append((UIModelHelper.create_end(self.board), 0))
            self.state = State.FINISH
            return

        # 次のプレイヤー手番の準備
        legal_actions = list(self.board.legal_actions(Color.BLACK))
        if self.board.num_stones == 16:
            from_set = set(a.src for a in legal_actions)
            state_list.append((UIModelHelper.create_from(self.board, from_set), 0))
            self.state = State.MOVE_FROM
        else:
            to_set = set(a.dst for a in legal_actions)
            state_list.append((UIModelHelper.create_put(self.board, to_set), 0))
            self.state = State.PUT_ON

    @staticmethod
    def choose_cpu_action(evaluator: Evaluator, board: Board, rejected_action: Action | None):
        import random
        second_bests = evaluator.up_to_second_best_actions(board, Color.WHITE)
        if rejected_action is not None:
            second_bests.remove(rejected_action)
        return random.choice(list(second_bests))

    def append_thinking_direction(self, state_list: list[(UIState, float)]):
        state_list.append((UIModelHelper.create_thinking(self.board), consts.CPU_THINK_DURATION))

    def clear_memory(self):
        self.sb_action = None
        self.from_index = None


class UIModelHelper:
    @staticmethod
    def create_stone_towers(board: Board) -> list[list[Color]]:
        return [list(tower) for tower in board]

    @classmethod
    def create_thinking(cls, board: Board) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [ButtonState(ButtonKind.BLANK, False) for _ in range(8)]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_put(cls, board: Board, target_set: set[int]) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.PUT_ON, True)
            if idx in target_set
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_from(cls, board: Board, from_set: set[int]) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.MOVE_FROM, True)
            if idx in from_set
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_to(cls, board: Board, to_set: set[int], src: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.MOVE_TO, True)
            if idx in to_set
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        buttons[src] = ButtonState(ButtonKind.CANCEL_FROM, True)
        return UIState(stone_towers, buttons)

    @staticmethod
    def create_center_sb() -> list[ButtonKind]:
        return [ButtonKind.ACCEPT, ButtonKind.REJECT]

    @classmethod
    def create_put_sb(cls, board: Board, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.PUT_ON, False)
            if idx == dst
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons, cls.create_center_sb())

    @classmethod
    def create_move_sb(cls, board: Board, src: int, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        m = {
            src: ButtonKind.MOVE_FROM,
            dst: ButtonKind.MOVE_TO
        }
        buttons = [
            ButtonState(m.get(idx, ButtonKind.BLANK), False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons, cls.create_center_sb())

    @classmethod
    def create_determined(cls, board: Board, action: Action) -> UIState:
        match action.kind:
            case ActionKind.PUT:
                return cls._create_determined_put(board, action.dst)
            case ActionKind.MOVE:
                return cls._create_determined_move(board, action.src, action.dst)

    @classmethod
    def _create_determined_put(cls, board: Board, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.PUT_ON, False)
            if idx == dst
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def _create_determined_move(cls, board: Board, src: int, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        m = {
            src: ButtonKind.MOVE_FROM,
            dst: ButtonKind.MOVE_TO
        }
        buttons = [
            ButtonState(m.get(idx, ButtonKind.BLANK), False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_end(cls, board: Board) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [ButtonState(ButtonKind.CANCEL_FROM, True) for _ in range(8)]
        return UIState(stone_towers, buttons)
