from enum import Enum, auto
from typing import NamedTuple, Callable

import consts
from enums import ButtonKind, Color
from board import Board, Evaluator, ActionKind, Action


class ButtonState(NamedTuple):
    kind: ButtonKind
    is_active: bool


class UIState(NamedTuple):
    stone_towers: list[list[Color]]
    buttons: list[ButtonState]
    center: list[ButtonKind] = []


class State(Enum):
    SELECT_COLOR = auto()
    MOVE_FROM = auto()
    MOVE_TO = auto()
    PUT_ON = auto()
    SECOND_BEST = auto()
    FINISH = auto()


class UIModel:
    def __init__(self, evaluator: Evaluator):
        self.state = State.SELECT_COLOR
        self.board = Board()
        self.player_color = Color.BLACK
        self.evaluator = evaluator
        self.from_index: int | None = None
        self.sb_action: Action | None = None

    def press(self, index: int) -> list[tuple[UIState, float]]:
        match self.state:
            case State.MOVE_FROM:
                return self.press_on_move_from(index)
            case State.MOVE_TO:
                return self.press_on_move_to(index)
            case State.PUT_ON:
                return self.press_on_put_on(index)
            case State.SECOND_BEST:
                raise NotImplementedError
            case State.FINISH:
                return self.press_on_retry(index)

        raise NotImplementedError

    def press_on_move_from(self, index: int) -> list[tuple[UIState, float]]:
        legal_actions = list(self.board.legal_actions(self.player_color))
        if all(a.kind != ActionKind.MOVE or a.src != index for a in legal_actions):
            return []

        to_set = set(a.dst for a in legal_actions if a.src == index and a != self.sb_action)
        self.from_index = index
        self.state = State.MOVE_TO
        ui_state = UIModelHelper.create_to(self.board, to_set, index)
        return [(ui_state, 0)]

    def press_on_move_to(self, index: int) -> list[tuple[UIState, float]]:
        def ui_state_when_rejected_creator(b: Board, a: Action) -> UIState:
            from_set_ = set(a_.src for a_ in legal_actions if a_ != a)
            return UIModelHelper.create_from(b, from_set_)

        def sb_ui_state_creator(b: Board, a: Action) -> UIState:
            return UIModelHelper.create_move_sb(b, a.src, a.dst)

        legal_actions = list(self.board.legal_actions(self.player_color))
        if index == self.from_index:
            self.state = State.MOVE_FROM
            from_set = set(a.src for a in legal_actions if a != self.sb_action)
            ui_state = UIModelHelper.create_from(self.board, from_set)
            self.from_index = None
            return [(ui_state, 0)]

        action = Action.create_move(self.player_color, self.from_index, index)
        return self._process_after_action_selected(
            action,
            State.MOVE_FROM,
            ui_state_when_rejected_creator,
            sb_ui_state_creator,
        )

    def press_on_put_on(self, index: int) -> list[tuple[UIState, float]]:
        def ui_state_when_rejected_creator(b: Board, a: Action) -> UIState:
            to_set_ = set(a_.dst for a_ in legal_actions if a_ != a)
            return UIModelHelper.create_put(b, to_set_)

        def sb_ui_state_creator(b: Board, a: Action) -> UIState:
            match a.kind:
                case ActionKind.PUT:
                    return UIModelHelper.create_put_sb(b, a.dst)
                case ActionKind.MOVE:
                    return UIModelHelper.create_move_sb(b, a.src, a.dst)
                case _:
                    raise NotImplementedError

        legal_actions = list(self.board.legal_actions(self.player_color))
        action = Action.create_put(self.player_color, index)

        return self._process_after_action_selected(
            action,
            State.PUT_ON,
            ui_state_when_rejected_creator,
            sb_ui_state_creator,
        )

    def _process_after_action_selected(
            self,
            action: Action,
            next_state_when_rejected: State,
            ui_state_when_rejected_creator: Callable[[Board, Action], UIState],
            sb_ui_state_creator: Callable[[Board, Action], UIState],
    ):
        legal_actions = list(self.board.legal_actions(self.player_color))

        if self.sb_action == action or action not in legal_actions:
            return []

        state_list = []

        # CPU のセカンドベスト判定
        if self.sb_action is None:
            if self.evaluator.best_actions(self.board, self.player_color) == {action}:
                if (winner := self.board.winner(~self.player_color, action)) is not None:  # セカンドベストで手が無くなったパターン
                    self.state = State.FINISH
                    if winner == self.player_color:
                        ui_state = UIModelHelper.create_player_won(self.board)
                    else:
                        ui_state = UIModelHelper.create_cpu_won(self.board)
                    state_list.append((ui_state, 0))
                    return state_list
                else:
                    self.state = next_state_when_rejected
                    self.clear_memory()
                    self.sb_action = action
                    state_list.append((ui_state_when_rejected_creator(self.board, action), 0))
                    return state_list

        # 確定
        self.board.perform(action)
        self.clear_memory()

        # ゲーム終了条件チェック
        if (winner := self.board.winner(self.player_color)) is not None:
            if winner == self.player_color:
                ui_state = UIModelHelper.create_player_won(self.board)
            else:
                ui_state = UIModelHelper.create_cpu_won(self.board)
            state_list.append((ui_state, 0))
            self.state = State.FINISH
            return state_list

        # ~~ CPU の手番 ~~
        self.append_thinking_direction(state_list)
        cpu_action = self.choose_cpu_action(self.evaluator, self.board, self.sb_action, ~self.player_color)
        self.sb_action = cpu_action
        self.state = State.SECOND_BEST
        state_list.append((sb_ui_state_creator(self.board, cpu_action), 0))
        return state_list

    def press_on_retry(self, _index: int) -> list[tuple[UIState, float]]:
        self.state = State.SELECT_COLOR
        return [(UIModelHelper.create_color_selection(), 0)]

    def press_central(self, index: int) -> list[tuple[UIState, float]]:
        match self.state:
            case State.SECOND_BEST:
                return self.press_central_second_best(index)
            case State.SELECT_COLOR:
                return self.press_central_select_color(index)
            case _:
                raise NotImplementedError

    def press_central_second_best(self, index: int) -> list[tuple[UIState, float]]:
        match index:
            case 0:
                return self.press_accept()
            case 1:
                return self.press_reject()
            case _:
                raise NotImplementedError

    def press_accept(self) -> list[tuple[UIState, float]]:
        state_list = []
        self.confirm_cpu_action(state_list, self.sb_action)
        return state_list

    def press_reject(self) -> list[tuple[UIState, float]]:
        state_list = []
        self.append_thinking_direction(state_list)
        cpu_action = self.choose_cpu_action(self.evaluator, self.board, self.sb_action, ~self.player_color)
        self.confirm_cpu_action(state_list, cpu_action)
        return state_list

    def confirm_cpu_action(self, state_list: list[tuple[UIState, float]], cpu_action: Action):
        # 確定
        self.board.perform(cpu_action)
        state_list.append((
            UIModelHelper.create_determined(self.board, cpu_action),
            consts.CPU_RESULT_DURATION,
        ))
        self.clear_memory()

        # ゲーム終了条件チェック
        if (winner := self.board.winner(~self.player_color)) is not None:
            if winner == self.player_color:
                ui_state = UIModelHelper.create_player_won(self.board)
            else:
                ui_state = UIModelHelper.create_cpu_won(self.board)
            state_list.append((ui_state, 0))
            self.state = State.FINISH
            return

        # 次のプレイヤー手番の準備
        legal_actions = list(self.board.legal_actions(self.player_color))
        if self.board.num_stones == 16:
            from_set = set(a.src for a in legal_actions)
            state_list.append((UIModelHelper.create_from(self.board, from_set), 0))
            self.state = State.MOVE_FROM
        else:
            to_set = set(a.dst for a in legal_actions)
            state_list.append((UIModelHelper.create_put(self.board, to_set), 0))
            self.state = State.PUT_ON

    def press_central_select_color(self, index) -> list[tuple[UIState, float]]:
        self.board = Board()
        self.clear_memory()
        match index:
            case 0:
                self.player_color = Color.BLACK
                self.state = State.PUT_ON
                return [(UIModelHelper.create_put(self.board, set(range(8))), 0)]
            case 1:
                self.player_color = Color.WHITE

                state_list = []
                self.append_thinking_direction(state_list)
                cpu_action = self.choose_cpu_action(self.evaluator, self.board, self.sb_action,
                                                    ~self.player_color)
                self.sb_action = cpu_action
                self.state = State.SECOND_BEST

                state_list.append((UIModelHelper.create_put_sb(self.board, cpu_action.dst), 0))
                return state_list
            case _:
                raise NotImplementedError

    @staticmethod
    def choose_cpu_action(evaluator: Evaluator, board: Board, rejected_action: Action | None, cpu_color: Color):
        import random
        second_bests = evaluator.up_to_second_best_actions(board, cpu_color)
        if rejected_action is not None:
            second_bests.remove(rejected_action)
        return random.choice(list(second_bests))

    def append_thinking_direction(self, state_list: list[(UIState, float)]):
        state_list.append((UIModelHelper.create_thinking(self.board), consts.CPU_THINK_DURATION))

    def clear_memory(self):
        self.sb_action = None
        self.from_index = None


class UIModelHelper:
    @staticmethod
    def create_stone_towers(board: Board) -> list[list[Color]]:
        return [list(tower) for tower in board]

    @classmethod
    def create_thinking(cls, board: Board) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [ButtonState(ButtonKind.BLANK, False) for _ in range(8)]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_put(cls, board: Board, target_set: set[int]) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.PUT_ON, True)
            if idx in target_set
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_from(cls, board: Board, from_set: set[int]) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.MOVE_FROM, True)
            if idx in from_set
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_to(cls, board: Board, to_set: set[int], src: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.MOVE_TO, True)
            if idx in to_set
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        buttons[src] = ButtonState(ButtonKind.CANCEL_FROM, True)
        return UIState(stone_towers, buttons)

    @staticmethod
    def create_center_sb() -> list[ButtonKind]:
        return [ButtonKind.ACCEPT, ButtonKind.REJECT]

    @classmethod
    def create_put_sb(cls, board: Board, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.PUT_ON, False)
            if idx == dst
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons, cls.create_center_sb())

    @classmethod
    def create_move_sb(cls, board: Board, src: int, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        m = {
            src: ButtonKind.MOVE_FROM,
            dst: ButtonKind.MOVE_TO
        }
        buttons = [
            ButtonState(m.get(idx, ButtonKind.BLANK), False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons, cls.create_center_sb())

    @classmethod
    def create_determined(cls, board: Board, action: Action) -> UIState:
        match action.kind:
            case ActionKind.PUT:
                return cls._create_determined_put(board, action.dst)
            case ActionKind.MOVE:
                return cls._create_determined_move(board, action.src, action.dst)

    @classmethod
    def _create_determined_put(cls, board: Board, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [
            ButtonState(ButtonKind.PUT_ON, False)
            if idx == dst
            else ButtonState(ButtonKind.BLANK, False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def _create_determined_move(cls, board: Board, src: int, dst: int) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        m = {
            src: ButtonKind.MOVE_FROM,
            dst: ButtonKind.MOVE_TO
        }
        buttons = [
            ButtonState(m.get(idx, ButtonKind.BLANK), False)
            for idx in range(8)
        ]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_cpu_won(cls, board: Board) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [ButtonState(ButtonKind.LOSE, True) for _ in range(8)]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_player_won(cls, board: Board) -> UIState:
        stone_towers = cls.create_stone_towers(board)
        buttons = [ButtonState(ButtonKind.WIN, True) for _ in range(8)]
        return UIState(stone_towers, buttons)

    @classmethod
    def create_color_selection(cls) -> UIState:
        stone_towers = [[] for _ in range(8)]
        buttons = [ButtonState(ButtonKind.BLANK, False) for _ in range(8)]
        center = [ButtonKind.PLAYS_FIRST, ButtonKind.PLAYS_SECOND]
        return UIState(stone_towers, buttons, center)
