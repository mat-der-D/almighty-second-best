from typing import Callable

import flet as ft

from enums import Color, ButtonKind
import consts


class Stone(ft.Container):
    def __init__(self, color: Color | None):
        self.__color = color
        super().__init__(
            width=consts.STONE_WIDTH,
            height=consts.STONE_HEIGHT,
            bgcolor=self._to_bgcolor(color)
        )

    @property
    def color(self) -> Color | None:
        return self.__color

    @color.setter
    def color(self, color: Color | None):
        self.__color = color
        self.bgcolor = self._to_bgcolor(color)
        self.update()

    @staticmethod
    def _to_bgcolor(color: Color | None) -> str:
        match color:
            case Color.BLACK:
                return ft.colors.BLACK
            case Color.WHITE:
                return ft.colors.WHITE
            case _:
                return ft.colors.TRANSPARENT


class Tower(ft.UserControl):
    def __init__(self, *colors: Color):
        super().__init__()
        tower_rev = [
            Stone(colors[idx]) if idx < len(colors) else Stone(None)
            for idx in range(3)
        ]
        self.__tower = tower_rev[::-1]

    def build(self):
        return ft.Column(
            controls=self.__tower,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=5
        )

    def set_colors(self, *colors: Color):
        for idx in range(3):
            self.__tower[2 - idx].color = colors[idx] if idx < len(colors) else None


class ButtonCreator:
    def __init__(
            self,
            theme_color: str = ft.colors.GREEN,
    ):
        self.theme_color = theme_color

    def create(self, kind: ButtonKind, on_click: Callable[[], None] | None) -> ft.ElevatedButton:
        btn = ft.ElevatedButton(
            text=self._text(kind),
            color=self._color(kind),
            width=self._width(kind),
            height=self._height(kind),
            on_click=on_click,
            style=self._style(kind),
            opacity=self._opacity(kind),
        )
        if (icon := self._icon(kind)) is not None:
            btn.content = ft.Row(
                [ft.Icon(name=icon, color=self._color(kind))],
                alignment=ft.MainAxisAlignment.CENTER,
            )
        btn.bgcolor = self._bgcolor(kind)
        return btn

    @staticmethod
    def _width(kind: ButtonKind) -> int:
        match kind:
            case ButtonKind.ACCEPT | ButtonKind.REJECT:
                return consts.BUTTON_WIDTH_WIDE
            case _:
                return consts.BUTTON_WIDTH_NARROW

    @staticmethod
    def _height(_kind: ButtonKind):
        return consts.BUTTON_HEIGHT

    @staticmethod
    def _text(kind: ButtonKind) -> str | None:
        match kind:
            case ButtonKind.MOVE_FROM:
                return "From"
            case ButtonKind.MOVE_TO:
                return "To"
            case ButtonKind.ACCEPT:
                return "Accept"
            case ButtonKind.REJECT:
                return "Reject"
            case ButtonKind.PLAYS_FIRST:
                return "1st"
            case ButtonKind.PLAYS_SECOND:
                return "2nd"
            case _:
                return None

    @staticmethod
    def _color(kind: ButtonKind) -> str:
        match kind:
            case ButtonKind.WIN:
                return ft.colors.YELLOW
            case ButtonKind.PLAYS_SECOND:
                return ft.colors.BLACK
            case _:
                return ft.colors.WHITE

    @staticmethod
    def _icon(kind: ButtonKind) -> str | None:
        match kind:
            case ButtonKind.CANCEL_FROM | ButtonKind.LOSE:
                return ft.icons.CANCEL
            case ButtonKind.WIN:
                return ft.icons.STAR
            case ButtonKind.PUT_ON:
                return ft.icons.CHECK
            case ButtonKind.RETRY:
                return ft.icons.REPLAY
            case _:
                return None

    def _style(self, kind: ButtonKind) -> ft.ButtonStyle | None:
        match kind:
            case ButtonKind.REJECT:
                return ft.ButtonStyle(side={
                    ft.MaterialState.DEFAULT: ft.BorderSide(3, self.theme_color),
                })
            case _:
                return None

    def _bgcolor(self, kind: ButtonKind) -> str:
        match kind:
            case ButtonKind.CANCEL_FROM | ButtonKind.LOSE:
                return ft.colors.RED
            case ButtonKind.WIN:
                return ft.colors.BLUE
            case ButtonKind.REJECT:
                return ft.colors.TRANSPARENT
            case ButtonKind.PLAYS_FIRST:
                return ft.colors.BLACK
            case ButtonKind.PLAYS_SECOND:
                return ft.colors.WHITE
            case _:
                return self.theme_color

    @staticmethod
    def _opacity(kind: ButtonKind) -> float:
        match kind:
            case ButtonKind.BLANK:
                return 0.5
            case _:
                return 1.0


class TowerButton(ft.UserControl):
    def __init__(self, tower: Tower, button: ft.ElevatedButton | None):
        super().__init__()
        self.__tower = tower
        self.__controls = [self.__tower]
        if button is not None:
            self.__controls.append(button)

    @classmethod
    def create_dummy(cls):
        return cls(Tower(), None)

    def build(self):
        return ft.Column(
            controls=self.__controls,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=5,
        )

    def set_button(self, button: ft.ElevatedButton):
        if len(self.__controls) < 2:
            return
        self.__controls[-1] = button
        self.update()

    def set_colors(self, *colors: Color):
        self.__tower.set_colors(*colors)


class TowerButtonCircle(ft.UserControl):
    def __init__(self, *tower_buttons: TowerButton):
        if len(tower_buttons) != 8:
            raise ValueError
        super().__init__()
        self.__tower_buttons = list(tower_buttons)

    def build(self):
        rows = []
        for x in range(4):
            row_contents = []
            for y in range(4):
                if (idx := self._coordinate_to_index(x, y)) is not None:
                    row_contents.append(self.__tower_buttons[idx])
                else:
                    row_contents.append(TowerButton.create_dummy())
            rows.append(
                ft.Row(
                    row_contents,
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )
        return ft.Column(
            rows,
            spacing=20,
            # alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )

    @staticmethod
    def _coordinate_to_index(x: int, y: int) -> int | None:
        try:
            return [(0, 2), (1, 3), (2, 3), (3, 2), (3, 1), (2, 0), (1, 0), (0, 1)].index((x, y))
        except ValueError:
            return None

    def set_button(self, index: int, button: ft.ElevatedButton):
        self.__tower_buttons[index].set_button(button)

    def set_colors(self, index: int, *colors: Color):
        self.__tower_buttons[index].set_colors(*colors)
