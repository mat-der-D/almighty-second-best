import functools

import flet as ft

import consts
from board import Evaluator
from ui_model import UIModel
from ui_controller import UIController
from components import ButtonCreator
import evaluator_binary

DEBUG_MODE = False


def main_app_debug(page: ft.Page):
    evaluator = evaluator_binary.EVALUATOR
    main_app(page, evaluator)


def main_app(page: ft.Page, evaluator: Evaluator):
    ui_controller = UIController(UIModel(evaluator), ButtonCreator())
    page.title = "Almighty Second Best"
    page.window_width = str(consts.PAGE_WIDTH)
    page.window_height = str(consts.PAGE_HEIGHT)
    page.bgcolor = ft.colors.BLUE_GREY_600
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.add(ui_controller.ui(page.width, page.height))


def main():
    if DEBUG_MODE:
        ft.app(main_app_debug)
    else:
        evaluator = evaluator_binary.EVALUATOR
        ft.app(functools.partial(main_app, evaluator=evaluator))


main()
