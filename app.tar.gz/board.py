import copy
from enum import Enum, auto
from typing import Iterable, NamedTuple
from enums import Color


class ActionKind(Enum):
    PUT = auto()
    MOVE = auto()


class Action(NamedTuple):
    kind: ActionKind
    player: Color
    src: int | None
    dst: int

    @classmethod
    def create_put(cls, color: Color, target: int):
        return cls(kind=ActionKind.PUT, player=color, src=None, dst=target)

    @classmethod
    def create_move(cls, color: Color, src: int, dst: int):
        return cls(kind=ActionKind.MOVE, player=color, src=src, dst=dst)


class Tower:
    def __init__(self):
        self._tower = []

    def __len__(self):
        return len(self._tower)

    def __iter__(self):
        return iter(self._tower)

    def __str__(self):
        return "".join(s.to_char() for s in self._tower)

    def swap_color(self):
        self._tower = [~stone for stone in self._tower]

    @property
    def is_empty(self) -> bool:
        return not self._tower

    @property
    def is_full(self) -> bool:
        return len(self._tower) == 3

    @property
    def top(self) -> Color | None:
        return None if self.is_empty else self._tower[-1]

    def put(self, color: Color) -> bool:
        if len(self._tower) < 3:
            self._tower.append(color)
            return True
        return False

    def remove(self) -> Color | None:
        if self._tower:
            return self._tower.pop()
        return None

    def to_int(self) -> int:
        id_ = 0
        for n, color in enumerate(self._tower[::-1]):
            if color is Color.BLACK:
                id_ |= 1 << n
        id_ |= 1 << len(self)
        return id_

    @classmethod
    def from_int(cls, id_: int) -> "Tower":
        for n in range(3, -1, -1):
            if id_ & (1 << n) == 0:
                continue
            colors = []
            for i in range(n):
                color = {
                    True: Color.BLACK,
                    False: Color.WHITE,
                }[bool(id_ & (1 << i))]
                colors.append(color)
            tower = Tower()
            tower._tower = colors[::-1]
            return tower
        raise ValueError


class ActionError(Exception):
    pass


class Board:
    def __init__(self):
        self._towers = [Tower() for _ in range(8)]

    def __iter__(self):
        return iter(self._towers)

    def __str__(self):
        return "\n".join(f"{pos}: {tower}" for pos, tower in enumerate(self._towers))

    def swap_color(self):
        for tower in self._towers:
            tower.swap_color()

    def copy(self) -> "Board":
        return copy.deepcopy(self)

    @property
    def num_stones(self) -> int:
        return sum(len(tower) for tower in self._towers)

    def canonical_player(self) -> Color:
        return {
            0: Color.BLACK,
            1: Color.WHITE,
        }[self.num_stones % 2]

    def perform(self, action: Action):
        match action.kind:
            case ActionKind.MOVE:
                self._move(action.src, action.dst)
            case ActionKind.PUT:
                self._put(action.player, action.dst)

    def _put(self, color: Color, target: int) -> bool:
        if not (0 <= target < 8):
            raise ValueError("target must be an integer between 0 and 7")
        return self._towers[target].put(color)

    def _move(self, src: int, dst: int):
        if not (0 <= src < 8 and 0 <= dst < 8):
            raise ValueError("src and dst must be integers between 0 and 7")
        color = self._towers[src].remove()
        if color is None:
            raise ActionError
        if not self._towers[dst].put(color):
            raise ActionError

    def is_legal(self, action: Action) -> bool:
        match action.kind:
            case ActionKind.PUT:
                return self._is_legal_put(action.player, action.dst)
            case ActionKind.MOVE:
                return self._is_legal_move(action.player, action.src, action.dst)

    def _is_legal_put(self, player: Color, target: int) -> bool:
        if not (0 <= target < 8):
            raise ValueError("target must be an integer between 0 and 7")
        return (self.num_stones < 16
                and self.canonical_player() == player
                and not self._towers[target].is_full)

    def _is_legal_move(self, player: Color, src: int, dst: int) -> bool:
        if not (0 <= src < 8 and 0 <= dst < 8):
            raise ValueError("src and dst must be integers between 0 and 7")
        if self.num_stones < 16:
            return False
        return (self.num_stones == 16
                and src != dst
                and self._towers[src].top == player
                and not self._towers[dst].is_full)

    def legal_actions(self, player: Color) -> Iterable[Action]:
        if self.num_stones == 16:
            # Move
            for src, tower_src in enumerate(self._towers):
                if tower_src.top != player:
                    continue
                for dst in ((src + 1) % 8, (src + 4) % 8, (src + 7) % 8):
                    if not self._towers[dst].is_full:
                        yield Action.create_move(player, src, dst)
        else:
            # Put
            if self.canonical_player() != player:
                return
            for target, tower in enumerate(self._towers):
                if not tower.is_full:
                    yield Action.create_put(player, target)

    def winner(self, recent_player: Color, rejected: Action | None = None) -> Color | None:
        is_white = False
        is_black = False
        for tower in self._towers:
            if not tower.is_full:
                continue
            is_black |= all(s is Color.BLACK for s in tower)
            is_white |= all(s is Color.WHITE for s in tower)
        for n in range(8):
            is_black |= all(self._towers[(n + i) % 8].top is Color.BLACK for i in range(4))
            is_white |= all(self._towers[(n + i) % 8].top is Color.WHITE for i in range(4))

        match (is_black, is_white):
            case (True, True):
                return recent_player
            case (True, False):
                return Color.BLACK
            case (False, True):
                return Color.WHITE
            case (False, False):
                pass

        next_player = ~recent_player
        possible_actions = set(self.legal_actions(next_player)) - {rejected}
        return None if possible_actions else recent_player

    def to_int(self) -> int:
        id_ = 0
        for n, tower in enumerate(self._towers):
            id_ |= tower.to_int() << (4 * n)
        return id_

    def to_canonical_int(self) -> int:
        def canonicalize_u32(x: int):
            def rotate(y: int) -> int:
                return ((y & 0x0fff_ffff) << 4) | ((y & 0xf000_0000) >> 28)

            def reverse(y: int) -> int:
                y = ((y & 0xf0f0_f0f0) >> 4) | ((y & 0x0f0f_0f0f) << 4)
                y = ((y & 0xff00_ff00) >> 8) | ((y & 0x00ff_00ff) << 8)
                y = ((y & 0xffff_0000) >> 16) | ((y & 0x0000_ffff) << 16)
                return y

            out = x
            tmp = x
            for _ in range(7):
                tmp = rotate(tmp)
                out = min(out, tmp)
            tmp = reverse(tmp)
            out = min(out, tmp)
            for _ in range(7):
                tmp = rotate(tmp)
                out = min(out, tmp)
            return out

        return canonicalize_u32(self.to_int())

    @classmethod
    def from_int(cls, id_: int) -> "Board":
        towers = []
        for n in range(8):
            towers.append(Tower.from_int(id_ & 0xf))
            id_ >>= 4
        board = cls()
        board._towers = towers
        return board


def load_ids(path: str) -> set[int]:
    ids = set()
    with open(path, "rb") as f:
        while True:
            data = f.read(4)
            if not data:
                break
            ids.add(int.from_bytes(data, "big"))
    return ids


class Evaluator:
    def __init__(self):
        self.loses = []
        self.wins = []
        self.both = set()

    @classmethod
    def create_from_sets(
            cls,
            wins_sets: Iterable[set[int]],
            loses_sets: Iterable[set[int]],
            both_set: set[int],
    ) -> "Evaluator":
        evaluator = cls()
        evaluator.wins = list(wins_sets)
        evaluator.loses = list(loses_sets)
        evaluator.both = both_set
        return evaluator

    @classmethod
    def load_from_dir(cls, root_dir: str) -> "Evaluator":
        import os
        wins_paths = [
            os.path.join(root_dir, f"W{n:0>3}.dat")
            for n in range(141)
        ]
        loses_paths = [
            os.path.join(root_dir, f"L{n:0>3}.dat")
            for n in range(141)
        ]
        both_path = os.path.join(root_dir, "Both.dat")
        return cls.load_from(wins_paths, loses_paths, both_path)

    @classmethod
    def load_from(
            cls,
            wins_paths: Iterable[str],
            loses_paths: Iterable[str],
            both_path: str,
    ) -> "Evaluator":
        evaluator = cls()
        evaluator.wins = [load_ids(path) for path in wins_paths]
        evaluator.loses = [load_ids(path) for path in loses_paths]
        evaluator.both = load_ids(both_path)
        return evaluator

    def evaluate_board(self, board: Board, player: Color) -> int:
        max_value = len(self.wins)
        min_value = -max_value

        b0 = board.copy()
        if b0.num_stones == 16 and player == Color.WHITE:
            b0.swap_color()

        id0 = b0.to_canonical_int()

        if id0 in self.both:
            return min_value

        for n, wins in enumerate(self.wins):
            if id0 in wins:
                return max_value - n

        for n, loses in enumerate(self.loses):
            if id0 in loses:
                return min_value + n

        return 0

    def evaluate_actions(self, board: Board, player: Color) -> dict[Action, int]:
        action_to_value = {}
        for a in board.legal_actions(player):
            b1 = board.copy()
            b1.perform(a)
            action_to_value[a] = - self.evaluate_board(b1, ~player)

        return action_to_value

    def best_actions(self, board: Board, player: Color) -> set[Action]:
        value_map = self.evaluate_actions(board, player)
        if not value_map:
            return set()
        max_value = max(value_map.values())
        return set(k for k, v in value_map.items() if v == max_value)

    def up_to_second_best_actions(self, board: Board, player: Color) -> set[Action]:
        value_map = self.evaluate_actions(board, player)
        values = sorted(value_map.values())
        if len(values) <= 1:
            return set(value_map.keys())
        second_max_value = values[-2]
        return set(k for k, v in value_map.items() if v >= second_max_value)
